package parte1;

import java.util.*;

public class Sistema {
	String Nome;
	private List<String> planetas;
	
	Sistema(String Nome, List<String> planetas) {
		this.Nome = Nome;
		this.planetas = planetas;
	}
	
	public List<String> getPlanetas() {
        return planetas;
    }
	
	public void AdicionaPlaneta(String Nome) {
		planetas.add(Nome);
	}
}
