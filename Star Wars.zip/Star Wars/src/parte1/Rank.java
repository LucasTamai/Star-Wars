package parte1;

public class Rank {
	int rank; //(0 - aprendiz; 1 - lorde; 2 - youngling; 3 - padawan; 4 - cavaleiro;5 - mestre)
	
}
