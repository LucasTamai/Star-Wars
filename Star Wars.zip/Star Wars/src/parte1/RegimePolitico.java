package parte1;

import java.util.*;

public class RegimePolitico {
	String Nome;
	int instituido;
	int dissolvido;
	String capital;
	private List<String> planetas;
	
	RegimePolitico(String Nome, int instituido, int dissolvido, String capital, List<String> planetas) {
		this.Nome = Nome;
		this.instituido = instituido;
		this.dissolvido = dissolvido;
		this.capital = capital;
		this.planetas = planetas;
	}
	
	public List<String> getPlanetas() {
        return planetas;
    }
	
	public void AdicionaPlaneta(String Nome) {
		planetas.add(Nome);
	}
}
