package parte1;

public class Cla {
	String Nome;
	int fundacao;
	int extinto;
}
