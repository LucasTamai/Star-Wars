package parte1;

public class Lorde extends Aprendiz{

}
