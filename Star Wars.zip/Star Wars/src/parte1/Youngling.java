package parte1;

public class Youngling extends Rank {
	
}
