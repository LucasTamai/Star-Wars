package parte1;

public class Ser {
	String Nome;
	String especie;	
	int nascimento;
	int midc;
}
