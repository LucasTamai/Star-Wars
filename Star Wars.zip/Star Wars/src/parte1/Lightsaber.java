package parte1;

public class Lightsaber {
	int cristal[]; // (indice 0 - define se ja coletou o cristal; indices 1 2 e 3 - cores referentes a RGB)
	int hilt; // (0 - nao possui sabre de luz; 1 - espada; 2 - lança;3 chicote; 4 tonfa)
}
