package parte1;

public class Academia {
	String Nome;
}
