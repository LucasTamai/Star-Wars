package parte1;

public class Aprendiz extends Rank{
	String nomeSith;
	boolean conhecimento; // (0 - nao possui conhecimento para construcao do sabre de luz)
}
