package parte1;

public class Knight extends Padawan{
	int DataAprovação;
}
