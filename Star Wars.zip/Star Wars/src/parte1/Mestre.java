package parte1;

public class Mestre extends Knight{
	int habilidade[]; //(indice 0 - imortalidade(bool); indice - 1 Tamanho do campo de videncia(km))
}
