package parte1;

public class Conselho {
	String Nome;	
}
