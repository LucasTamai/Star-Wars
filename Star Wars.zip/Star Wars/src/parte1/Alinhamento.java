package parte1;

public class Alinhamento {
	int percentual; // (percentual de raiva ou paz interna)
	boolean Poder[]; //(indice 0 - telepatia; 1 - telecinese; 2 persuasão)
	
}
