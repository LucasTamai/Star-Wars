package parte1;

public class Missao {
	String Nome;
	String obj;	
	boolean Resultado;	
	
}
