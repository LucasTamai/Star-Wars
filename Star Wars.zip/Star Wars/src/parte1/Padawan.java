package parte1;

public class Padawan extends Youngling{
	int trança; //(comprimento em cm)
	boolean conhecimento; // (0 - nao possui conhecimento para construcao do sabre de luz)

}
