package parte1;

public class Ordem {
	String Nome;
	boolean Atributo; //(0 - raiva;1 - paz)
}
