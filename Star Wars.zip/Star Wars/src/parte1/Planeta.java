package parte1;

public class Planeta {
	String cor;
	int diametro;
	String Nome;
	String capital;
	String reg;
	String sist;
	
	Planeta(String cor, int diametro, String Nome, String capital) {
		this.cor = cor;
		this.diametro = diametro;
		this.Nome = Nome;
		this.capital = capital;
	}
	
	public void AdicionaEmRegime(RegimePolitico regi) {
		this.reg = regi.Nome;
		regi.AdicionaPlaneta(this.Nome);
	}
	public void AdicionaEmSistema(Sistema sisti) {
		this.sist = sisti.Nome;
		sisti.AdicionaPlaneta(this.Nome);
	}
}
