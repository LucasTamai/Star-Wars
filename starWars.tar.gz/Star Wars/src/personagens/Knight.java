package personagens;

public class Knight extends Padawan{
	int DataAprovação;

	public int getDataAprovação() {
		return DataAprovação;
	}

	public void setDataAprovação(int dataAprovação) {
		DataAprovação = dataAprovação;
	}
}
