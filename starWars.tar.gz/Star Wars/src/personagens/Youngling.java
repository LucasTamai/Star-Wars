package personagens;

public class Youngling extends Jedi {

}
