package personagens;

public class Jedi extends Alinhamento {
    private Cla cla;

    public Cla getCla() {
        return cla;
    }

    public void setCla(Cla cla) {
        this.cla = cla;
    }
}
