package personagens;

public class Aprendiz extends Sith{
	private boolean conhecimento; // (0 - nao possui conhecimento para construcao do sabre de luz)

	public boolean isConhecimento() {
		return conhecimento;
	}

	public void setConhecimento(boolean conhecimento) {
		this.conhecimento = conhecimento;
	}
}
