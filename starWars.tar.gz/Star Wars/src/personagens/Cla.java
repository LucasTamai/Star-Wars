package personagens;

import java.util.List;

public class Cla {
	private String Nome;
	private int fundacao;
	private int extinto;
	private Mestre mestre;
	private List<Jedi>  jediList;

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public int getFundacao() {
		return fundacao;
	}

	public void setFundacao(int fundacao) {
		this.fundacao = fundacao;
	}

	public int getExtinto() {
		return extinto;
	}

	public void setExtinto(int extinto) {
		this.extinto = extinto;
	}

	public Mestre getMestre() {
		return mestre;
	}

	public void setMestre(Mestre mestre) {
		this.mestre = mestre;
	}

	public List<Jedi> getJediList() {
		return jediList;
	}

	public void setJediList(List<Jedi> jediList) {
		this.jediList = jediList;
	}
}
