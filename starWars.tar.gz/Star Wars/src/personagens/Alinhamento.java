package personagens;

public class Alinhamento {
	private Ordem ordem;
	private int percentual;
	private String[] poderes;
	private Lightsaber lightsaber;


	public Alinhamento() {

	}

	public Alinhamento(String nome, int percentual, String[] poderes) {
		this.percentual = percentual;
		this.poderes = poderes;
	}


	public int getPercentual() {
		return percentual;
	}

	public void setPercentual(int percentual) {
		this.percentual = percentual;
	}

	public Ordem getOrdem() {
		return ordem;
	}

	public void setOrdem(Ordem ordem) {
		this.ordem = ordem;
	}

	public String[] getPoderes() {
		return poderes;
	}

	public void setPoderes(String[] poderes) {
		this.poderes = poderes;
	}
}