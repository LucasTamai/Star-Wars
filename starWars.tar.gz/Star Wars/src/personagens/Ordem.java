package personagens;

import parte1.universo.Academia;

import java.util.List;

public class Ordem {
	private String Nome;
	private boolean Atributo; //(0 - raiva;1 - paz)
	private List<Academia> academias;

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public boolean isAtributo() {
		return Atributo;
	}

	public void setAtributo(boolean atributo) {
		Atributo = atributo;
	}

	public List<Academia> getAcademias() {
		return academias;
	}

	public void setAcademias(List<Academia> academias) {
		this.academias = academias;
	}
}
