package personagens;

public class Padawan extends Youngling{
	private int trança; //(comprimento em cm)
	private boolean conhecimento; // (0 - nao possui conhecimento para construcao do sabre de luz)
	private Mestre mestre;

	public int getTrança() {
		return trança;
	}

	public void setTrança(int trança) {
		this.trança = trança;
	}

	public boolean isConhecimento() {
		return conhecimento;
	}

	public void setConhecimento(boolean conhecimento) {
		this.conhecimento = conhecimento;
	}

	public Mestre getMestre() {
		return mestre;
	}

	public void setMestre(Mestre mestre) {
		this.mestre = mestre;
	}
}
