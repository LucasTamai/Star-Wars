package parte1.universo;

import java.util.*;

public class Sistema {
	private String Nome;
	private List<Planeta> planetas;
	
	Sistema(String Nome, List<Planeta> planetas) {
		this.Nome = Nome;
		this.planetas = planetas;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public List<Planeta> getPlanetas() {
		return planetas;
	}

	public void setPlanetas(List<Planeta> planetas) {
		this.planetas = planetas;
	}
}
