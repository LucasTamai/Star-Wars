package parte1.universo;

import personagens.Ser;

import java.util.List;

public class Conselho {
	private String Nome;
	private List<Ser> membros;

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public List<Ser> getMembros() {
		return membros;
	}

	public void setMembros(List<Ser> membros) {
		this.membros = membros;
	}
}
