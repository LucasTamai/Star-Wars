package parte1.universo;

import personagens.Ser;

import java.util.List;

public class Missao {
	private String Nome;
	private String obj;
	private List<Ser> agentes;
	private List<Ser> envolvidos;
	private List<Planeta> planetas;
	private boolean Resultado;


	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getObj() {
		return obj;
	}

	public void setObj(String obj) {
		this.obj = obj;
	}

	public List<Ser> getAgentes() {
		return agentes;
	}

	public void setAgentes(List<Ser> agentes) {
		this.agentes = agentes;
	}

	public List<Ser> getEnvolvidos() {
		return envolvidos;
	}

	public void setEnvolvidos(List<Ser> envolvidos) {
		this.envolvidos = envolvidos;
	}

	public List<Planeta> getPlanetas() {
		return planetas;
	}

	public void setPlanetas(List<Planeta> planetas) {
		this.planetas = planetas;
	}

	public boolean isResultado() {
		return Resultado;
	}

	public void setResultado(boolean resultado) {
		Resultado = resultado;
	}
}
